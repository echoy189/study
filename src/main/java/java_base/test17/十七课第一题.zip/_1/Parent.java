package eight.test17._1;

public class Parent {

    void piPing(double score) {
        if (score < 60) {
            System.out.println("批评");
        } else System.out.println("奖励");
    }
}
