package eight.kaoshi.test8;

public interface Teacher {
    abstract void gaiZuoYe();

    abstract void tongZhi(Parent p);


}
