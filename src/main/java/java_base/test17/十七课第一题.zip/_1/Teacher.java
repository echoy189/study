package eight.test17._1;

public interface Teacher {


    abstract void gaiZuoYe(double score);

    static void tongZhi() {
        System.out.println("改完作业");
    }


}
