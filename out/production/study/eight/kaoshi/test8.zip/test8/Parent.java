package eight.kaoshi.test8;

public interface Parent {

    abstract void piPing(double score) ;


}
